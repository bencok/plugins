<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$type = intval($_GET['trtype']);

$link = $type == 1 ? unserialize ( get_post_meta( intval(get_query_var('trid')), 'trglinks_'.intval(get_query_var('trembed')), true ) ) : unserialize ( get_term_meta( intval(get_query_var('trid')), 'trglinks_'.intval(get_query_var('trembed')), true ) );

$link = base64_decode( $link['link'] );

$a = array( '&amp;amp;lt;', '&amp;amp;quot;', '&amp;amp;gt;', '&amp;lt;', '&amp;quot;', '&amp;gt;', '&lt;', '&quot;', '&gt;' );
$b = array( '<', '"', '>', '<', '"', '>', '<', '"', '>' );
$link = str_replace( $a, $b, $link );

preg_match('#<iframe(.*?)></iframe>#is', html_entity_decode($link), $matches);

preg_match('/\[(.*?)\]/', html_entity_decode($link), $matshortcode);

if( isset($matshortcode[0]) ) {
    $link = do_shortcode( $matshortcode[0] );
}elseif( isset($matches[0]) ) {
    $link = html_entity_decode($link, ENT_QUOTES, 'UTF-8');
    preg_match('/<iframe.*src=\"(.*)\".*><\/iframe>/isU', $link, $matches);
    if( in_array( tr_grabber_get_domain_from_url($matches[1]), tr_grabber_frame_servers() ) ) {
        $link = str_replace($matches[1], esc_url( home_url( '/' ) ).'/?trhide=1&tid='.strrev(bin2hex($matches[1])).'&', $link);
    }
}else{
    if( in_array( tr_grabber_get_domain_from_url($link), tr_grabber_frame_servers() ) ) {
        $link = str_replace($link, esc_url( home_url( '/' ) ).'?trhide=1&tid='.strrev(bin2hex($link)).'&', $link);
    }
    $link = '<iframe width="560" height="315" src="'.$link.'" frameborder="0" allowfullscreen></iframe>';
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <title><?php _e('Embed', 'tr-grabber'); ?></title>
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="robots" content="noindex,nofollow">
    <style>body,html,.Video,iframe{width: 100%;height: 100%;margin: 0;font-size: 0;}</style>
</head>
<body oncontextmenu="return false;">
    
    <div class="Video">   <?php
   $resposta = false;
   if (isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])) {
      $captcha_data = $_POST['g-recaptcha-response'];
      $chave_secreta = 'CHAVE_SECRETA';   
      $resposta = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=$chave_secreta&response=$captcha_data&remoteip='.$_SERVER['REMOTE_ADDR']);
   }
   if ($resposta) {
   ?><?php echo $link; ?><?php }?>

   <?php
   if(!$resposta){
   ?>
   
      <script src='https://www.google.com/recaptcha/api.js'></script><div class='wrap'>
   <form method='post' onsubmit='return validar()'>
      <div class='g-recaptcha' data-callback='recaptchaCallback' data-sitekey='6LcYzEUdAAAAAOKGK4ltK_2g5b51RzDhOCAmiNUJ'></div>
      <br>
  <div id="ninth" class="buttonBox">
    <button>Liberar video</button>
  </div>
</form></div>
<script>(function(a,b,c){Object.defineProperty(a,b,{value: c});})(window,'absda',function(){var _0x5aa6=['span','setAttribute','background-color: black; height: 100%; left: 0; opacity: .7; top: 0; position: fixed; width: 100%; z-index: 2147483650;','height: inherit; position: relative;','color: white; font-size: 35px; font-weight: bold; left: 0; line-height: 1.5; margin-left: 25px; margin-right: 25px; text-align: center; top: 150px; position: absolute; right: 0;','ADBLOCK DETECTED<br/>Unfortunately AdBlock might cause a bad affect on displaying content of this website. Please, deactivate it.','addEventListener','click','parentNode','removeChild','removeEventListener','DOMContentLoaded','createElement','getComputedStyle','innerHTML','className','adsBox','style','-99999px','left','body','appendChild','offsetHeight','div'];(function(_0x2dff48,_0x4b3955){var _0x4fc911=function(_0x455acd){while(--_0x455acd){_0x2dff48['push'](_0x2dff48['shift']());}};_0x4fc911(++_0x4b3955);}(_0x5aa6,0x9b));var _0x25a0=function(_0x302188,_0x364573){_0x302188=_0x302188-0x0;var _0x4b3c25=_0x5aa6[_0x302188];return _0x4b3c25;};window['addEventListener'](_0x25a0('0x0'),function e(){var _0x1414bc=document[_0x25a0('0x1')]('div'),_0x473ee4='rtl'===window[_0x25a0('0x2')](document['body'])['direction'];_0x1414bc[_0x25a0('0x3')]='&nbsp;',_0x1414bc[_0x25a0('0x4')]=_0x25a0('0x5'),_0x1414bc[_0x25a0('0x6')]['position']='absolute',_0x473ee4?_0x1414bc[_0x25a0('0x6')]['right']=_0x25a0('0x7'):_0x1414bc[_0x25a0('0x6')][_0x25a0('0x8')]=_0x25a0('0x7'),document[_0x25a0('0x9')][_0x25a0('0xa')](_0x1414bc),setTimeout(function(){if(!_0x1414bc[_0x25a0('0xb')]){var _0x473ee4=document[_0x25a0('0x1')](_0x25a0('0xc')),_0x3c0b3b=document[_0x25a0('0x1')](_0x25a0('0xc')),_0x1f5f8c=document[_0x25a0('0x1')](_0x25a0('0xd')),_0x5a9ba0=document['createElement']('p');_0x473ee4[_0x25a0('0xe')]('style',_0x25a0('0xf')),_0x3c0b3b['setAttribute']('style',_0x25a0('0x10')),_0x1f5f8c[_0x25a0('0xe')](_0x25a0('0x6'),'color: white; cursor: pointer; font-size: 50px; font-weight: bold; position: absolute; right: 30px; top: 20px;'),_0x5a9ba0[_0x25a0('0xe')](_0x25a0('0x6'),_0x25a0('0x11')),_0x5a9ba0[_0x25a0('0x3')]=_0x25a0('0x12'),_0x1f5f8c[_0x25a0('0x3')]='&#10006;',_0x3c0b3b['appendChild'](_0x5a9ba0),_0x3c0b3b[_0x25a0('0xa')](_0x1f5f8c),_0x1f5f8c[_0x25a0('0x13')](_0x25a0('0x14'),function _0x3c0b3b(){_0x473ee4[_0x25a0('0x15')][_0x25a0('0x16')](_0x473ee4),_0x1f5f8c['removeEventListener']('click',_0x3c0b3b);}),_0x473ee4[_0x25a0('0xa')](_0x3c0b3b),document[_0x25a0('0x9')][_0x25a0('0xa')](_0x473ee4);}},0xc8),window[_0x25a0('0x17')]('DOMContentLoaded',e);});});</script><script type='text/javascript' onerror='absda()' src='//fireworkswad.com/ad/20/d0/ad20d0bb8243dd053cceffd6f93fae09.js'></script>
<style>

.wrap {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* NINTH HOVER */

#ninth>button{
  transition:all .5s ease-in-out;
}

#ninth:hover button{
  background: #121212;
  color: #ffc000;
}
.buttonBox{
  position:relative;
  max-width: 200px;
  min-width: 150px;
  flex: 20%;
}

button{
  width: 300px;
  height:80px;
  position:relative;
  background: #181818;
  text-transform:uppercase;
  color:white;
  font-weight:700;
  letter-spacing:1px;
  border:none;
  font-size:15px;
  outline:none;
  font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
  cursor: pointer;
}
</style>
   </form>

   <script>
   googlerecpchk = false;
   function recaptchaCallback() {
      googlerecpchk = true;
   };

   function validar(){

      console.log(googlerecpchk);
      if(!googlerecpchk){
         alert('reCaptcha inválido!');
         return false;
      }

   }
   </script>
<?php }?>
</div>
    
</body>
</html>